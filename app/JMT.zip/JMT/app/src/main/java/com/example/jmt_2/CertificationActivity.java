package com.example.jmt_2;

public class CertificationActivity {
}
